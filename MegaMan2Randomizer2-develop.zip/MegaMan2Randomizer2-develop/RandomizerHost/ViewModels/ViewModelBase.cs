﻿using ReactiveUI;

namespace RandomizerHost.ViewModels
{
    public class ViewModelBase : ReactiveObject
    {
    }
}
