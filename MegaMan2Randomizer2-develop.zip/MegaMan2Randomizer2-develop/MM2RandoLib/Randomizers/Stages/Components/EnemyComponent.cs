﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MM2Randomizer.Randomizers.Stages.Components
{
    class EnemyComponent
    {
    }
}
