﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MM2Randomizer.Random
{
    public enum GeneratorType
    {
        Default,
        MT19937,
    }
}
