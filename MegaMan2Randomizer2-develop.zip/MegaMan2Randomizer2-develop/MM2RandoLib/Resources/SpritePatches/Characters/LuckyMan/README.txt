Luckyman sprite ripped by Charlieboy, credit for Luckyman sprite to Chico
title intro edits and sprite fixes credit to Charlieboy
