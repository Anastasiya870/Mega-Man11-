Quickman sprite ripped by Charlieboy from Rockman CX
Credit for Quickman sprite to Himajin Jichiku
title intro edits and sprite fixes credit to Charlieboy