CutmanBSD hud elements rip by megakyle83 

Credit 
Sprites ripped from Cutman's Bad Scissors Day romhack 
by JASON HAYES, EEDIOT, GENIOUS OF AMERICA, YES.