https://megaman.fandom.com/wiki/Kerog
https://megaman.fandom.com/wiki/Kerog#Petit_Kerog
