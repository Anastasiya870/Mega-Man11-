A_Special_Joe.ips by ProdigyRTA

https://megaman.fandom.com/wiki/Sniper_Joe#Returning_Sniper_Joe
https://megaman.fandom.com/wiki/Sniper_Joe#Sniper_Armor
