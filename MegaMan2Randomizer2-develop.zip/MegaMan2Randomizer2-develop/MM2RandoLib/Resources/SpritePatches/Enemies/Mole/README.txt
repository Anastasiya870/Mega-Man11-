MM9drill_mole ripped by ProdigyRTA

https://megaman.fandom.com/wiki/Mole