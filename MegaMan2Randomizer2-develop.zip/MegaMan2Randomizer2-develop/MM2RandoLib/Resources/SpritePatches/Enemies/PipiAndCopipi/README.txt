Pipi_carries_a_bomb by ProdigyRTA

https://megaman.fandom.com/wiki/Pipi
https://megaman.fandom.com/wiki/Pipi#Copipi
