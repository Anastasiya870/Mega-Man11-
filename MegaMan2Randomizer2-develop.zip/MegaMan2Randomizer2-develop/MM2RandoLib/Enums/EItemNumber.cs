﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MM2Randomizer.Enums
{
    public enum EItemNumber
    {
        None = 0,
        One = 1,
        Two = 2,
        Three = 4
    }
}
