﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MM2Randomizer.Enums
{
    public enum ERMPortraitText
    {
        HeatMan = 0x02F035,
        AirMan = 0x02EF3D,
        WoodMan = 0x02F045,
        BubbleMan = 0x02EF35,
        QuickMan = 0x02EF45,
        FlashMan = 0x02F13D,
        MetalMan = 0x02F135,
        CrashMan = 0x02F145
    }
}
