﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MM2Randomizer.Enums
{
    public enum EMiscAddresses
    {
        WarpXCoordinateStartAddress = 0x038280,
        WarpYCoordinateStartAddress = 0x038278
    }
}
