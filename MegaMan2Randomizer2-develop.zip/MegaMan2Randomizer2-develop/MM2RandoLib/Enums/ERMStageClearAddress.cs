﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MM2Randomizer.Enums
{
    public enum ERMStageClearAddress
    {
        HeatMan = 0x07C289,
        AirMan = 0x07C28A,
        WoodMan = 0x07C28B,
        BubbleMan = 0x07C28C,
        QuickMan = 0x07C28D,
        FlashMan = 0x07C28E,
        MetalMan = 0x07C28F,
        CrashMan = 0x07C290,
    }
}
