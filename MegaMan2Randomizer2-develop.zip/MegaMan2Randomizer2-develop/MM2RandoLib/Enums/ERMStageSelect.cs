﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MM2Randomizer.Enums
{
    public enum ERMStageSelect
    {
        //Not sure what the stage select order is but this is the starting Mem
        FirstStageInMemory = 0x0346E1
    }
}
