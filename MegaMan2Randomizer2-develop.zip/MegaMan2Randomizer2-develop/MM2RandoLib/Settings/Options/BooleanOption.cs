﻿using System.ComponentModel;

namespace MM2Randomizer.Settings.Options
{
    public enum BooleanOption
    {
        [Description("False")]
        False = 0,

        [Description("True")]
        True = 1,
    }
}
