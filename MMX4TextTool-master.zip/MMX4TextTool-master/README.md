# MMX4TextTool
Mega Man X4 Text editing tool

This is a tool to edit texts from Mega Man X4, that can be found on "PL00_U.ARC" and other files I guess. Just read the usage and you'll find all necessary instructions.
